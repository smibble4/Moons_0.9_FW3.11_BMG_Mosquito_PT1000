#ifndef OPTIBOOT_XFLASH_H
#define OPTIBOOT_XFLASH_H

extern uint8_t optiboot_xflash_enter();

#endif /* OPTIBOOT_XFLASH_H */
